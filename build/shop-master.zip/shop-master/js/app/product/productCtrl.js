/**
 * Created by Vista on 06.02.17.
 */

var productCtrl = {
    index: function () {
        $('.top-user-image img').attr('src', localStorage.user_avatar);
        $('.photo-wrap_inner img').attr('src', localStorage.user_avatar);
        var successCallback = function (result) {
            console.log(result);
            for (var i in result) {
                var source = $("#product-template").html();
                var template = Handlebars.compile(source);
                if (result[i].price === "") {
                    result[i].price = "не указана";
                }
                var html = template(result[i]);
                $("#product-template-parent").append(html);
            }
        };
        var errorCallback = function (result) {
            console.log(result);
        };
        var data = {
            limit: 15,
            offset: 0
        };
        requestService.get(urlService.product.index, data, successCallback, errorCallback)
    },
    product_view: function (id) {
        window.location = "product-preview.html?id=" + id;
    },
    load_product: function () {
        $('.top-user-image img').attr('src', localStorage.user_avatar);
        $('.photo-wrap_inner img').attr('src', localStorage.user_avatar);
        var id = location.search.split("id=")[1];
        var data = {
            id: id
        };
        var successCallback = function (result) {
            console.log(result);
            // for (var i in result) {
            var source = $("#product_about_template").html();
            var template = Handlebars.compile(source);
            // if (result[i].price === "") {
            //     result[i].price = "не указана";
            // }
            var html = template(result);
            $("#product_about_parent").append(html);
            // }

        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.get(urlService.product.view, data, successCallback, errorCallback)
    }
};