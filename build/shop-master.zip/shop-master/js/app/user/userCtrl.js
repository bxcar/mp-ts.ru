/**
 * Created by Vista on 27.01.17.
 */

var loginCtrl = {
    reg_data: '',
    login: function () {
        var form = $('form[name=login_form]');
        var successCallback = function (result) {
            console.log(result);
            if (result.status) {
                localStorage.auth_key = result.auth_key;
                localStorage.user_id = result.user_id;
                window.location = 'user-profile-view.html?user=' + result.user_id;
            }
        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.post(urlService.user.login, form.serialize(), successCallback, errorCallback)
    },
    registration: function (form_name) {
        var form = $('form[name=reg_form]');
        var successCallback = function (result) {
            console.log(result);
            if (result.status) {
                alert('Пользователь успешно зарегистрирован');
                $('.btn.login')[0].click();

            }
        };
        var errorCallback = function (result) {
            console.log(result);
        };
        if (typeof form_name !== 'undefined') {
            var custom_form = $('form[name=' + form_name + '_form]');
            var data = new FormData();
            var form_data = form.serializeArray();
            for (var i in form_data) {
                data.append(form_data[i].name, form_data[i].value)
            }
            data.append('doc', custom_form.find('input[name=doc]')[0].files[0])
            xhr = new XMLHttpRequest();

            xhr.open('POST', urlService.api + urlService.user.sign_up, true);
            xhr.onreadystatechange = function (response) {
                console.log(response);
                if (xhr.readyState == XMLHttpRequest.DONE) {
                    if (JSON.parse(xhr.responseText).status) {
                        alert('Данные успешно сохранены');
                        window.location = 'user-profile-view.html';
                        return false;
                    }
                    else {
                        alert('Произошла ошибка');
                        return false;
                    }
                }

            };

            xhr.send(data);
        }
        else {
            requestService.post(urlService.user.sign_up, form.serialize(), successCallback, errorCallback)
        }
    },
    next_step: function () {
        loginCtrl.reg_data = $('form[name=reg_form]');
    },
    profile: function () {
        var id = location.search.split("user=")[1];
        var data = {
            auth_key: localStorage.auth_key,
        };
        if (typeof id !== 'undefined') {
            data.id = id;
        } else {
            data.id = localStorage.user_id;
        }

        var successCallback = function (result) {
            console.log(result);
            result.avatar = "http://www.svm.biz.ua/api/web/img/" + result.avatar;
            if (result.id === parseInt(localStorage.user_id)) {
                localStorage.user_avatar = result.avatar;
            }
            $('.top-user-image img').attr('src', localStorage.user_avatar);
            $('.photo-wrap_inner img').attr('src', localStorage.user_avatar);
            localStorage.userdata = JSON.stringify(result);
            var source = $("#user-about-template").html();
            var template = Handlebars.compile(source);
            var html = template(result);
            $("#user-about-parent").append(html);
        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.get(urlService.user.profile, data, successCallback, errorCallback)
    },
    profile_edit: function () {
        $('.top-user-image img').attr('src', localStorage.user_avatar);
        $('.photo-wrap_inner img').attr('src', localStorage.user_avatar);
        var source = $("#user-about-edit-template").html();
        var template = Handlebars.compile(source);
        var html = template(JSON.parse(localStorage.userdata));
        $("#user-about-edit-parent").append(html);
    },
    save_profile: function () {
        var form = $('form[name=user-edit-form]');
        var fd = new FormData();
        var file = document.getElementById('file');
        fd.append('avatar', file.files[0]);
        fd.append('username', form.find($('input[name="username"]')).val());
        fd.append('city', form.find($('input[name="city"]')).val());
        fd.append('sex', form.find($('select[name="sex"]')).val());
        fd.append('date_birth', form.find($('input[name="date_birth"]')).val());
        fd.append('email', form.find($('input[name="email"]')).val());
        fd.append('phone', form.find($('input[name="phone"]')).val());
        fd.append('user_id', localStorage.user_id);
        xhr = new XMLHttpRequest();

        xhr.open('POST', urlService.api + urlService.user.profile_update, true);
        xhr.onreadystatechange = function (response) {
            console.log(response);
            if (xhr.readyState == XMLHttpRequest.DONE) {
                if (JSON.parse(xhr.responseText).status) {
                    alert('Данные успешно сохранены');
                    window.location = 'user-profile-view.html';
                    return false;
                }
                else {
                    alert('Произошла ошибка');
                    return false;
                }
            }

        };

        xhr.send(fd);
        // requestService.post(urlService.user.profile_update, fd, successCallback, errorCallback)
    },
    sendEntry: function () {
        var form = $('form[name=entry_form]');
        var fd = new FormData();
        var file = document.getElementById('file_entry');
        fd.append('file', file.files[0]);
        fd.append('text', form.find($('textarea[name="text"]')).val());
        fd.append('sender_id', localStorage.user_id);
        var user_id = location.search.split("user=")[1];
        if (typeof user_id === 'undefined') {
            user_id = localStorage.user_id;
        }
        fd.append('getter_id', user_id);
        xhr = new XMLHttpRequest();

        xhr.open('POST', urlService.api + urlService.entry.add, true);
        xhr.onreadystatechange = function (response) {
            console.log(response);
            if (xhr.readyState == XMLHttpRequest.DONE) {
                if (JSON.parse(xhr.responseText).status) {
                    // alert('Данные успешно сохранены');
                    // window.location.reload();
                    loginCtrl.getEntries();
                }
                else {
                    // alert('Произошла ошибка');
                    return false;
                }
            }

        };

        xhr.send(fd);
    },
    getEntries: function () {
        $("#post-item-parent").empty();
        var id = location.search.split("user=")[1];
        var data = {
            auth_key: localStorage.auth_key,
        };
        if (typeof id !== 'undefined') {
            data.id = id;
        } else {
            data.id = localStorage.user_id;
        }
        var successCallback = function (result) {
            console.log(result);
            for (var i in result.data) {
                var obj = result.data[i];
                obj.avatar = "http://www.svm.biz.ua/api/web/img/" + obj.avatar;
                if (obj.attachment !== null) {
                    obj.attachment = "http://www.svm.biz.ua/api/web/img/" + obj.attachment;
                }
                obj.comment_avatar = localStorage.user_avatar;
                var a = moment(obj.create_date * 1000);
                obj.create_date = a.fromNow();
                obj.comments_count = obj.comments.length;
                var source = $("#post-item-template").html();
                var template = Handlebars.compile(source);
                var html = template(obj);
                $("#post-item-parent").append(html);
            }

        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.get(urlService.entry.get, data, successCallback, errorCallback)

    },
    sendComment: function (id) {
        var form = $('form[name=commentForm-' + id + ']');
        var successCallback = function (result) {
            console.log(result);
            if (result.status) {
                loginCtrl.getEntries();
            }
        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.post(urlService.comment.add, form.serialize(), successCallback, errorCallback)

    },
    friend_list: function () {
        $('.top-user-image img').attr('src', localStorage.user_avatar);
        $('.photo-wrap_inner img').attr('src', localStorage.user_avatar);
        var successCallback = function (result) {
            console.log(result);
            for (var i in result) {
                var obj = result[i];
                obj.avatar = "http://www.svm.biz.ua/api/web/img/" + obj.avatar;
                var source = $("#friend-list-item-template").html();
                var template = Handlebars.compile(source);
                var html = template(obj);
                $("#friend-list-parent").append(html);
            }
            friendInfo();
        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.get(urlService.user.friend_list, {id: localStorage.user_id}, successCallback, errorCallback)

    },
    friend_one: function () {
        $('.top-user-image img').attr('src', localStorage.user_avatar);
        $('.photo-wrap_inner img').attr('src', localStorage.user_avatar);
        var id = location.search.split("user=")[1];
        var data = {
            id: id
        };
        var successCallback = function (result) {
            console.log(result);

        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.get(urlService.user.friend_one, data, successCallback, errorCallback)
    },
    getFeedBack: function () {
        var data = {
            id: location.search.split("user=")[1]
        };
        console.log(data);
        $("#feed_back_parent").empty();
        var successCallback = function (result) {
            console.log(result);
            $('.user-comments .user-top-list img').attr('src', "http://www.svm.biz.ua/api/web/img/" + result.user.avatar);
            $('.user-comments .user-top-list .user-name').text(result.user.username);
            for (var i in result.data) {
                var obj = result.data[i];
                obj.avatar = "http://www.svm.biz.ua/api/web/img/" + obj.avatar;
                var source = $("#feed_back_item").html();
                var template = Handlebars.compile(source);
                var html = template(obj);
                $("#feed_back_parent").append(html);
            }
        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.get(urlService.feedback.get, data, successCallback, errorCallback)

    },
    sendFeedBack: function () {
        var form = $('form[name=feed_back_form]');
        var data = {
            sender_id: localStorage.user_id,
            getter_id: location.search.split("user=")[1],
            text: form.find('textarea[name=text]').val()
        };
        console.log(data);
        var successCallback = function (result) {
            console.log(result);
            if (result) {
                loginCtrl.getFeedBack();
            }
        };
        var errorCallback = function (result) {
            console.log(result);
        };
        requestService.post(urlService.feedback.add, data, successCallback, errorCallback)

    },
    sendMsg: function (id) {
        var form = $('form[name=msg_form]');
        var data = {
            getter_id: id,
            sender_id: localStorage.user_id,
            text: form.find('textarea[name=message]').val()
        };
        console.log(data);
    }
};