/**
 * Created by Vista on 27.01.17.
 */

var urlService = {
    api: 'http://www.svm.biz.ua/api/web/v1/',
    // api: 'http://localhost:8888/shop/api/web/v1/',
    user: {
        login: 'user/login?',
        sign_up: 'user/sign-up?',
        profile: 'user/index?',
        profile_update: 'user/update?',
        friend_list: 'user/friends?',
        friend_one: 'user/friend-one?'
    },
    entry: {
        add: 'entry/create?',
        get: 'entry/index?'
    },
    product: {
        index: 'product/index?',
        view: 'product/view?'
    },
    comment: {
        add: 'comment/create?'
    },
    feedback: {
        add: 'comment/feed-back-add',
        get:'comment/feed-back-index'
    }
};